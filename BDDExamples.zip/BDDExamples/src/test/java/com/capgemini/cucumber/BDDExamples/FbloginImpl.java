package com.capgemini.cucumber.BDDExamples;

import cucumber.api.java.en.*;

public class FbloginImpl {
	@Given("^The user had logined into fb\\.com website$")
	public void the_user_had_logined_into_fb_com_website() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 
		
	}

	@When("^the user provides valid username and password$")
	public void the_user_provides_valid_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^the user shld be directed to welcome page of Fb$")
	public void the_user_shld_be_directed_to_welcome_page_of_Fb() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^the user provides invalid username and password$")
	public void the_user_provides_invalid_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^the user shld be directed to login page again$")
	public void the_user_shld_be_directed_to_login_page_again() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^User didnt provide username and password but still clicks login button$")
	public void user_didnt_provide_username_and_password_but_still_clicks_login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}


}
