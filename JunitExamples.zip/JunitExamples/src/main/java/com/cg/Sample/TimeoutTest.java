package com.cg.Sample;

import org.junit.Test;

public class TimeoutTest {

	   String message = "Robert";	
	   
	   @Test(timeout = 1000)
	   public void testPrintMessage() {	
	      System.out.println("Inside testPrintMessage()");     
	     
	   }

	   @Test
	   public void testSalutationMessage() {
	      System.out.println("Inside testSalutationMessage()");
	      message = "Hi!" + "Robert";
	   
	   }
	}