package com.capgemini.sample.JunitExamples;

import org.junit.Test;

public class ExceptTest1 {

	@Test(expected=ArithmeticException.class)
	public void fin()
	{
		ExceptTest.testing();
	}
}
