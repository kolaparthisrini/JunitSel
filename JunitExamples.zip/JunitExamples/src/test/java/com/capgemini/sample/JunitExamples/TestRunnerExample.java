package com.capgemini.sample.JunitExamples;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunnerExample {
public static void main(String...a)
{
	Result result=JUnitCore.runClasses(AppTest.class,
			        CalcTest.class);
	for(Failure fl:result.getFailures())
	{
		System.out.println(fl.toString());
	}
	System.out.println(result.wasSuccessful());
	
}
}
